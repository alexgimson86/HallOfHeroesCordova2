This is a Cordova plugin that adds the Android Support v4 client library.
It is meant to be depended on by other plugins.

